package com.mohamadk.globaladapter

import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.list_fragment.*

class SampleListFragment: BaseListFragment() {


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)




        list.apply {
            adapter=Gene

        }




    }



}