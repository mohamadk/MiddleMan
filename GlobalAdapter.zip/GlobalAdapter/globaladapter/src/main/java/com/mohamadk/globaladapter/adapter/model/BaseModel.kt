package com.mohamadk.globaladapter.adapter.model

import android.content.Context
import android.os.Parcelable
import android.view.View
import androidx.annotation.LayoutRes

interface BaseModel : ModelComparator<BaseModel>, Parcelable {
    @LayoutRes
    fun defaultResLayout(): Int?{
        return null
    }

    fun defaultView(context: Context): View?
}