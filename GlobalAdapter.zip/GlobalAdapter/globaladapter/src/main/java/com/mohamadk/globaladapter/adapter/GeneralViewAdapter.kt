package com.mohamadk.globaladapter.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.mohamadk.globaladapter.adapter.model.BaseModel
import com.mohamadk.globaladapter.adapter.networkstate.NetworkState
import com.mohamadk.globaladapter.intractors.BaseIntractor
import com.mohamadk.globaladapter.intractors.RequireInteractor
import java.lang.IllegalStateException

open class GeneralViewAdapter<MODEL : BaseModel>(
    private val interact: BaseIntractor? = null
) : RecyclerView.Adapter<RecyclerView.ViewHolder>()
    , AdapterProvider<List<MODEL>> {

    private var networkState: NetworkState? = null
    var items: List<MODEL> = listOf()
    var inflater: LayoutInflater? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {

        if (inflater == null) {
            inflater = LayoutInflater.from(parent.context)
        }

        val itemView: View = when {
            items[viewType].defaultResLayout() != null -> inflater!!.inflate(
                items[viewType].defaultResLayout()!!,
                parent,
                false
            )
            items[viewType].defaultView(parent.context) != null -> items[viewType].defaultView(parent.context)!!
            else -> throw IllegalStateException("Please implement defaultResLayout or defaultView in ${items[viewType]::class.java.name} model")
        }

        if (itemView is RequireInteractor<*>) {
            (itemView as RequireInteractor<BaseIntractor>).setInteractor(interact!!)
        }

        return GlobalViewHolder<MODEL>(itemView)

    }


    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        (holder as GlobalViewHolder<MODEL>).bind(getItem(position))
    }

    private fun getItem(position: Int): MODEL {
        return items[position]
    }

    override fun submitList(items: List<MODEL>?) {
        this.items = items ?: listOf()
        notifyDataSetChanged()
    }

    override fun getAdapter(): RecyclerView.Adapter<RecyclerView.ViewHolder> {
        return this
    }


    private fun hasExtraRow() = networkState != null && networkState != NetworkState.LOADED

    override fun getItemViewType(position: Int): Int {
        return position
    }

    override fun getItemCount(): Int {
        return items.size + if (hasExtraRow()) 1 else 0
    }

    override fun setNetworkState(newNetworkState: NetworkState?) {
        val previousState = this.networkState
        val hadExtraRow = hasExtraRow()
        this.networkState = newNetworkState
        val hasExtraRow = hasExtraRow()
        if (hadExtraRow != hasExtraRow) {
            if (hadExtraRow) {
                notifyItemRemoved(items.size)
            } else {
                notifyItemInserted(items.size)
            }
        } else if (hasExtraRow && previousState != newNetworkState) {
            notifyItemChanged(itemCount - 1)
        }
    }


}