package com.mohamadk.globaladapter.intractors

interface RetryListener : BaseIntractor {
    fun retry()
}