package com.mohamadk.globaladapter.intractors

interface BaseIntractor